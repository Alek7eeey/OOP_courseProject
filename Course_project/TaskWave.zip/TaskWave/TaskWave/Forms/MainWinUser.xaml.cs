﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TaskWave.Classes;
using TaskWave.DataBase;
using TaskWave.Pages.SnadartUser.MyTask;

namespace TaskWave.Forms
{
    /// <summary>
    /// Логика взаимодействия для MainWinUser.xaml
    /// </summary>
    public partial class MainWinUser : Window
    {
        public MainWinUser()
        {
            InitializeComponent();
            Cursor = new Cursor("D:\\studing\\4_semestr\\Course_project\\Cursor\\Red Neon\\normal_select.cur");
            this.DataContext = new ViewModelMainWinUser();
            Classes.NavigationService.mainFr = FraimMainInAcc;
            Classes.NavigationService.img = imgBrush;
            Classes.NavigationService.textBlock = NameBl;

            //myContext context = new();
            //// создание проекта
            //Classes.Projects p2 = new Classes.Projects();
            //p2.name = "123Сделать групповое задание";
            //p2.description = "Сделайте груповое задание";
            //p2.dateTo = DateTime.Parse("18-07-2023");
            //p2.dateOt = DateTime.Parse("06-06-2023");
            //p2.type = "team";
            //p2.nameOfCreator = activeUser.user.login;

            //var bitmapImage2 = new BitmapImage(new Uri("D:\\studing\\4_semestr\\Course_project\\image\\avatar.png"));
            //byte[] imageBytes2;
            //using (MemoryStream ms = new MemoryStream())
            //{
            //    PngBitmapEncoder encoder = new PngBitmapEncoder();
            //    encoder.Frames.Add(BitmapFrame.Create(bitmapImage2));
            //    encoder.Save(ms);
            //    imageBytes2 = ms.ToArray();
            //}
            //PrPhoto ph1 = new();
            //ph1.Data = imageBytes2;
            //ph1.PrId = p2.id;

            //p2.images = new List<PrPhoto>();
            //p2.images.Add(ph1);
            //context.SaveChanges();

            //// сохранение проекта в базу данных
            //context.Database.EnsureCreated();
            //context.projects.Add(p2);
            //context.SaveChanges();

            //// создание задачи и связывание ее с проектом
            //Classes.Tasks task = new Classes.Tasks();
            //task.name = "Сделать задание 1";
            //task.description = "Напишите pch.cpp";
            //task.dateTo = DateTime.Parse("12-09-2023");
            //task.dateOt = DateTime.Parse("12-05-2023");
            //task.ProjectId = p2.id;
            //task.nameOfCreator = activeUser.user.login;

            //Classes.Tasks task2 = new Classes.Tasks();
            //task2.name = "Сделать задание 2";
            //task2.description = "Напишите sdk.h";
            //task2.dateTo = DateTime.Parse("04-05-2023");
            //task2.dateOt = DateTime.Parse("11-05-2023");
            //task2.ProjectId = p2.id;
            //task2.nameOfCreator = activeUser.user.login;

            //// добавление задачи в список задач проекта
            //p2.tasks = new List<Classes.Tasks>();
            //p2.tasks.Add(task);
            //p2.tasks.Add(task2);

            //// сохранение изменений в базу данных
            //context.SaveChanges();

            //var bitmapImage = new BitmapImage(new Uri("D:\\studing\\4_semestr\\Course_project\\image\\avatar.png"));
            //byte[] imageBytes;
            //using (MemoryStream ms = new MemoryStream())
            //{
            //    PngBitmapEncoder encoder = new PngBitmapEncoder();
            //    encoder.Frames.Add(BitmapFrame.Create(bitmapImage));
            //    encoder.Save(ms);
            //    imageBytes = ms.ToArray();
            //}
            //TaskPhoto ph = new();
            //ph.Data = imageBytes;
            //ph.TaskId = task2.id;

            //task.img = new List<TaskPhoto>();
            //task.img.Add(ph);
            //context.SaveChanges();
            ////*********************************************************************************
            //// создание проекта
            //Classes.Projects p3 = new Classes.Projects();
            //p3.name = "Сделать лабораторную";
            //p3.description = "Необходимо для лабораторной работы номер 8 по ПСП разработать данное приложение";
            //p3.dateTo = DateTime.Parse("18-07-2023");
            //p3.dateOt = DateTime.Parse("06-06-2023");
            //p3.nameOfCreator = activeUser.user.login;

            //// сохранение проекта в базу данных
            //context.Database.EnsureCreated();
            //context.projects.Add(p3);
            //context.SaveChanges();

            //// создание задачи и связывание ее с проектом
            //Classes.Tasks task3 = new Classes.Tasks();
            //task3.name = "Напишите заголовочный файл";
            //task3.description = "Напишите arr.h";
            //task3.dateTo = DateTime.Parse("12-05-2023");
            //task3.dateOt = DateTime.Parse("14-05-2023");
            //task3.ProjectId = p3.id;
            //task3.nameOfCreator = activeUser.user.login;

            //// добавление задачи в список задач проекта
            //p3.tasks = new List<Classes.Tasks>();
            //p3.tasks.Add(task3);

            //// сохранение изменений в базу данных
            //context.SaveChanges();
        }
    }
}
