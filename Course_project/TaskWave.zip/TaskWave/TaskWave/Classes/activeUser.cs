﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskWave.DataBase;

namespace TaskWave.Classes
{
    public class activeUser
    {
        public static string passw = "";
        public static User? user;
    }
}
